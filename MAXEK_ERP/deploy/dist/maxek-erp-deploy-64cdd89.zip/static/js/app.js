document.addEventListener('DOMContentLoaded', function () {
  const category = document.getElementById('worker_category');
  const subcontractorRow = document.getElementById('subcontractor-row');
  if (category && subcontractorRow) {
    function toggleSubcontractor() {
      subcontractorRow.style.display = category.value === 'Sub Contractor Staff' ? 'block' : 'none';
    }
    category.addEventListener('change', toggleSubcontractor);
    toggleSubcontractor();
  }
});
